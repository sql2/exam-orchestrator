CREATE DATABASE util_test;
CREATE TABLES util_test.t1 (a char(30)) ENGINE=MEMORY;
