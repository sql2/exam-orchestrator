echo "failover stopped" > ./failover_stop.log 
date >> ./failover_stop.log

