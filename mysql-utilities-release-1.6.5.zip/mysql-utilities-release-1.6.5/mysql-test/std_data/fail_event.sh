#!/bin/sh

mkdir fail_event
