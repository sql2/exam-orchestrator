#!/bin/sh

echo "# ARGUMENTS PASSED:"
echo "# old master host: " $1
echo "# old master port: " $2
echo "# new master host: " $3
echo "# new master port: " $4
