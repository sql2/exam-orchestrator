echo "failover starts" > ./failover_start.log 
date >> ./failover_start.log

